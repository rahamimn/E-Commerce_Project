var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "001_Login"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 20641.0
        }
      ],
      [
        {
          "run": 1,
          "value": 20641.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "001_Login"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 20845.0
        }
      ],
      [
        {
          "run": 1,
          "value": 20845.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "001_Login"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  }
}