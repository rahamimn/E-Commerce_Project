var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 21769.0
        }
      ],
      [
        {
          "run": 1,
          "value": 28905.0
        }
      ],
      [
        {
          "run": 1,
          "value": 12098.0
        }
      ],
      [
        {
          "run": 1,
          "value": 24305.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 18759.0
        }
      ],
      [
        {
          "run": 1,
          "value": 28871.0
        }
      ],
      [
        {
          "run": 1,
          "value": 12477.0
        }
      ],
      [
        {
          "run": 1,
          "value": 19407.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  }
}