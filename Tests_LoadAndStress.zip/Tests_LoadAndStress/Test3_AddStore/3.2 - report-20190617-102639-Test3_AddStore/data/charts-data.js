var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 35310.0
        }
      ],
      [
        {
          "run": 1,
          "value": 61050.0
        }
      ],
      [
        {
          "run": 1,
          "value": 12251.0
        }
      ],
      [
        {
          "run": 1,
          "value": 32628.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 21654.0
        }
      ],
      [
        {
          "run": 1,
          "value": 61062.0
        }
      ],
      [
        {
          "run": 1,
          "value": 12559.0
        }
      ],
      [
        {
          "run": 1,
          "value": 21558.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_Redirect to User-panel",
      "003_Add Store"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0633
        }
      ],
      [
        {
          "run": 1,
          "value": 0.122
        }
      ],
      [
        {
          "run": 1,
          "value": 0.068
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  }
}