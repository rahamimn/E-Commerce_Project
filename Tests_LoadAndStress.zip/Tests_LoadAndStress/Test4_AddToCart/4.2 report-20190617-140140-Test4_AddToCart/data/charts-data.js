var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_User-Panel",
      "003_Products",
      "004_Product Page",
      "005_Add to Cart"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 21858.0
        }
      ],
      [
        {
          "run": 1,
          "value": 28577.0
        }
      ],
      [
        {
          "run": 1,
          "value": 15380.0
        }
      ],
      [
        {
          "run": 1,
          "value": 12141.0
        }
      ],
      [
        {
          "run": 1,
          "value": 33900.0
        }
      ],
      [
        {
          "run": 1,
          "value": 19289.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_User-Panel",
      "003_Products",
      "004_Product Page",
      "005_Add to Cart"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 19830.0
        }
      ],
      [
        {
          "run": 1,
          "value": 26884.0
        }
      ],
      [
        {
          "run": 1,
          "value": 11548.0
        }
      ],
      [
        {
          "run": 1,
          "value": 6238.0
        }
      ],
      [
        {
          "run": 1,
          "value": 34125.0
        }
      ],
      [
        {
          "run": 1,
          "value": 19071.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "001_Login",
      "002_User-Panel",
      "003_Products",
      "004_Product Page",
      "005_Add to Cart"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.2464
        }
      ],
      [
        {
          "run": 1,
          "value": 0.284
        }
      ],
      [
        {
          "run": 1,
          "value": 0.48200000000000004
        }
      ],
      [
        {
          "run": 1,
          "value": 0.256
        }
      ],
      [
        {
          "run": 1,
          "value": 0.21
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  }
}