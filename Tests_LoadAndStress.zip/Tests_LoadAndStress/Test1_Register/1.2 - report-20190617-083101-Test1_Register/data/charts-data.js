var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "001_Homepage",
      "002_Register",
      "003_Redirect to homepage"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 13129.0
        }
      ],
      [
        {
          "run": 1,
          "value": 5377.0
        }
      ],
      [
        {
          "run": 1,
          "value": 23798.0
        }
      ],
      [
        {
          "run": 1,
          "value": 10211.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "001_Homepage",
      "002_Register",
      "003_Redirect to homepage"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 8589.0
        }
      ],
      [
        {
          "run": 1,
          "value": 2870.0
        }
      ],
      [
        {
          "run": 1,
          "value": 27771.0
        }
      ],
      [
        {
          "run": 1,
          "value": 6234.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "001_Homepage",
      "002_Register",
      "003_Redirect to homepage"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.3093
        }
      ],
      [
        {
          "run": 1,
          "value": 0.254
        }
      ],
      [
        {
          "run": 1,
          "value": 0.45399999999999996
        }
      ],
      [
        {
          "run": 1,
          "value": 0.22
        }
      ]
    ]
  }
}